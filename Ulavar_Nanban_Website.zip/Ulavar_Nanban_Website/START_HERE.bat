@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo  Ulavar Nanban - Website Prototype
echo ==============================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found.
  echo Install the Node.js LTS version from https://nodejs.org/ and reopen this file.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing project packages for the first time...
  call npm install
  if errorlevel 1 (
    echo Package installation failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)
echo Starting the local website...
call npm run dev
pause
