# Ulavar Nanban — Farmer Empowerment Website Prototype

A responsive React + Vite prototype for a multilingual farmer support website. It is designed for a college/hackathon demonstration and includes interactive screens for:

1. **Farmer dashboard** — personalised by crop and district, quick action plan, sample market snapshot.
2. **Profit planner** — calculates estimated sales, commission, expenses, net profit and profit margin; compares illustrative market options.
3. **Disaster support** — interactive preparedness checklist, crop-damage next steps and official information links.
4. **Government scheme finder** — searchable/filterable resource cards with official portal links and eligibility/document guidance.
5. **Grievance assistant** — creates an editable complaint draft in the selected UI language; users can copy it and submit it themselves through the appropriate official channel.
6. **Language assistant** — English, Tamil and Hindi interface labels, guided Q&A, optional browser speech-to-text and text-to-speech.
7. **Farmer profile** — district, crop, crop stage, preferred language; saved locally in the browser.

## Run in VS Code (Windows)

### Requirements
- Node.js LTS installed (includes npm)
- VS Code

### Steps
1. Extract `Ulavar_Nanban_Website.zip` to a folder, for example `C:\Users\YourName\Downloads\Ulavar_Nanban_Website`.
2. Open VS Code → **File → Open Folder** → select the extracted folder.
3. Open **Terminal → New Terminal**.
4. Run:

   ```powershell
   npm install
   npm run dev
   ```

5. Open the local URL printed in the terminal (usually `http://localhost:5173`).

**Shortcut:** after Node.js is installed, you can also double-click `START_HERE.bat`; it installs packages if needed and starts the development server.
6. To test a production build:

   ```powershell
   npm run build
   npm run preview
   ```

## How to demonstrate

- Change language to Tamil and Hindi in the top-right menu.
- Open **Profit planner**, change quantity/price/cost/transport/commission and show the live calculation.
- Open **Disaster support** and tick checklist items.
- Open **Govt. schemes**, search and filter Central / Tamil Nadu resources, then open official links.
- Open **Raise a grievance**, fill in an issue and generate/edit/copy the complaint draft.
- Open **Ask Ulavar Nanban**, try a suggested question or use the microphone (browser support required).
- Open **Farmer profile**, save a name/district/crop and return to the dashboard.

## Important prototype limitations

This is an interactive front-end demo, **not a production government service**. It intentionally does not claim to provide live data or automatic government submissions:

- Market prices are sample values; no live mandi/AGMARKNET API is connected.
- Disaster page links to official sources but does not fetch live weather/disaster alerts or use GPS.
- Scheme cards are starter resource guides, not a live scheme/deadline database. Check current rules, eligibility and deadlines at the official portals.
- The assistant uses simple topic matching and prepared responses; it is not connected to an LLM or government backend.
- Voice input depends on browser speech-recognition support (typically Chrome/Edge, with internet/browser permissions as required). Text-to-speech uses the browser's speech engine and available voices.
- UI labels are translated into English, Tamil and Hindi; some scheme descriptions and official source content remain in English because they come from official portal names/details.
- Profile preferences are stored in browser `localStorage`. There is no account login, server, encrypted document storage or multi-user backend. Do not enter Aadhaar numbers, bank credentials, OTPs or sensitive personal information.
- Complaint text is generated locally and is **not submitted automatically**. The user must review it, select the appropriate official channel and submit it themselves.

## Main files

```text
Ulavar_Nanban_Website/
├── index.html
├── START_HERE.bat
├── package.json
├── README.md
└── src/
    ├── main.jsx
    ├── App.jsx
    └── styles.css
```

## Suggested next steps for a real deployment

1. Connect verified market prices (e.g. an authorised AGMARKNET/data.gov.in source) and show the source timestamp.
2. Integrate official weather alerts and district-specific warning data.
3. Build a maintained scheme catalogue with official source, eligibility, last-checked date and deadline fields.
4. Add a secure backend, authentication, privacy notice and consent before storing personal data.
5. For any complaint automation, use only an authorised integration; otherwise provide a clear official link and manual submission guide.
